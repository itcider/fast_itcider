if(window.innerWidth < 768) {
    document.querySelector('.adsenseconfig-left').remove();
    document.getElementsByClassName('adsenseconfig-left').remove();
    $(".adsenseconfig-left").remove();
}    
